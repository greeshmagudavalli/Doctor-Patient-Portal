# Doctor-Patient-Portal : Advance Java WebProject
Doctor Patient Portal is an Advance Java Web Project. Technology used in this project Advance JAVA concepts like JSP, JSTL, Servlet, HTML, CSS, Boostrap 5, Fontawesome and MySQL

# Project View: Some of Screenshots of this project are given below 

# Home Page:

![1 0 Home Page_1](https://user-images.githubusercontent.com/91146041/205282972-18a37392-538a-477a-8fb5-c28636b666c4.png)

![1 1 Home Page_2](https://user-images.githubusercontent.com/91146041/205282986-f5efe4b3-abf6-4059-bb98-50788f8142c7.png)

# Admin Login:
![2 0 Admin Login](https://user-images.githubusercontent.com/91146041/205282991-aa2add0e-4442-4041-8535-686f324300fa.png)

# Admin Dashboard:
![2 1 Admin Dash Board](https://user-images.githubusercontent.com/91146041/205282994-08164397-981f-49ed-b492-a5e75a0c58e4.png)

# Add Specialist:
![2 2 Add Specialist](https://user-images.githubusercontent.com/91146041/205282996-09b1a30c-4919-4336-9b3e-45953b9c9d51.png)

# Add Doctor:
![2 3 Add Doctor](https://user-images.githubusercontent.com/91146041/205283000-92b9b560-2a3a-4f01-82d2-ad313e1a7653.png)

# Doctor List:
![2 4 List of Doctor](https://user-images.githubusercontent.com/91146041/205283003-45e45a28-722d-4ffd-b762-d116335e9789.png)

# No. of Patients Appointment:
![2 5 Patient List](https://user-images.githubusercontent.com/91146041/205283006-93c834b1-1f88-4ba9-9e50-7cf54f15661b.png)

# Doctor Login:
![3 0 Doctor Login](https://user-images.githubusercontent.com/91146041/205283010-3b80f5a6-2a12-46cb-abf5-23c8131f2115.png)

# Doctor Dashboard:
![3 1 Doctor Dash Board](https://user-images.githubusercontent.com/91146041/205283016-902df9d7-eb76-41f0-9e11-7e2b46390b99.png)

# View list of Patient Appointment:
![3 2 Doctor view Patient Appointment](https://user-images.githubusercontent.com/91146041/205283019-fa94c37e-9a82-4195-8724-891d7465ed38.png)

# Edit/Change Profile Details:
![3 3 Doctor-Edit and Change password](https://user-images.githubusercontent.com/91146041/205283021-531eef60-6da8-417a-9b8d-5554608af19f.png)

# Prescribe medicine / Treatment Comment:
![3 4 Prescribe medicine and comment](https://user-images.githubusercontent.com/91146041/205283023-b1e52979-6d69-4f4a-afcf-153b93b9d7ba.png)

# User Register first for Appointment Request:
![4 0 User register](https://user-images.githubusercontent.com/91146041/205283034-196f20f7-c1fd-4ee3-9b04-5e208f89a7d8.png)

# User Login:
![4 1 User Login](https://user-images.githubusercontent.com/91146041/205283038-1c24b1ad-48e7-452f-8528-8c4609b6b9d6.png)

# User 1 Dashboard:
![4 2 1 User Dash Board_1](https://user-images.githubusercontent.com/91146041/205283041-23e6d78f-f3e9-4ef7-95e2-000f44344bdf.png)

# User 2 Dashboard:
![4 2 2 User dashboar_2](https://user-images.githubusercontent.com/91146041/205283047-6fdc5a37-7da8-4640-90ea-e2768126b58b.png)

# Make Appointment Request:
![4 3 User Appointment](https://user-images.githubusercontent.com/91146041/205283049-bceb5fdb-e686-4d2b-afe3-0a35bbafa1dd.png)

# View list of appointment
![4 4 User view appointment](https://user-images.githubusercontent.com/91146041/205283053-6b00959a-a2b1-4285-a040-67e7c1bcbe2c.png)


# Have a nice day 

# Thank you for visiting my profile.


